Overleaf project for the uploaded DOCX report

Files:
- main.tex: LaTeX source generated from the DOCX using Pandoc.
- media/: extracted images used by the report.

To use in Overleaf:
1. Create a New Project > Upload Project.
2. Upload eventbook_latex.zip.
3. Set main.tex as the Main document if needed.
4. Choose XeLaTeX as the compiler if Unicode characters or symbols cause issues.

Note:
This is a content conversion, not a pixel-perfect recreation of the original Word layout.
Review page breaks, tables, image sizing, headers/footers, and any special symbols in Overleaf.
Update the candidate name, institution, dates, technology stack, screenshots, and project details
so the final report accurately describes your own work. Do not submit another person's work as your own.

Page layout update: main.tex now uses US Letter paper with the source DOCX margins: top/bottom 1 inch and left/right 0.875 inch.
